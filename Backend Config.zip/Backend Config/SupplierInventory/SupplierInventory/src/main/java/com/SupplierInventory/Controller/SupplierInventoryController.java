package com.SupplierInventory.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.SupplierInventory.Entity.SupplierInventoryEntity;
import com.SupplierInventory.Service.SupplierInventoryService;

import java.util.List;

@RestController
@RequestMapping("/api/supplier-inventory")
public class SupplierInventoryController {

    @Autowired
    private SupplierInventoryService supplierInventoryService;

    @GetMapping
    public ResponseEntity<List<SupplierInventoryEntity>> getAllSupplierInventories() {
        List<SupplierInventoryEntity> inventories = supplierInventoryService.getAllSupplierInventories();
        return new ResponseEntity<>(inventories, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<SupplierInventoryEntity> getSupplierInventoryById(@PathVariable String id) {
        SupplierInventoryEntity inventory = supplierInventoryService.getSupplierInventoryById(id);
        return inventory != null
                ? new ResponseEntity<>(inventory, HttpStatus.OK)
                : new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @PostMapping
    public ResponseEntity<SupplierInventoryEntity> addSupplierInventory(@RequestBody SupplierInventoryEntity inventory) {
        SupplierInventoryEntity addedInventory = supplierInventoryService.addSupplierInventory(inventory);
        return new ResponseEntity<>(addedInventory, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<SupplierInventoryEntity> updateSupplierInventory(
            @PathVariable String id, @RequestBody SupplierInventoryEntity updatedInventory) {
        SupplierInventoryEntity inventory = supplierInventoryService.updateSupplierInventory(id, updatedInventory);
        return inventory != null
                ? new ResponseEntity<>(inventory, HttpStatus.OK)
                : new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteSupplierInventory(@PathVariable String id) {
        supplierInventoryService.deleteSupplierInventory(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}