package com.SupplierInventory;



import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SupplierInventoryApplication {

	public static void main(String[] args) {
		SpringApplication.run(SupplierInventoryApplication.class, args);
	}

}
