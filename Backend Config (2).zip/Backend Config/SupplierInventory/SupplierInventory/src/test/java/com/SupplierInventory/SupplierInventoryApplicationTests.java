package com.SupplierInventory;

import org.junit.jupiter.api.Test;

import org.springframework.boot.test.context.SpringBootTest;

import com.SupplierInventory.Entity.SupplierInventoryEntity;
import com.SupplierInventory.Repository.SupplierInventoryRepository;
import com.SupplierInventory.Service.SupplierInventoryService;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;


import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.ArgumentMatchers.any;





@SpringBootTest
class SupplierInventoryApplicationTests {

	@Test
	void contextLoads() {
	}

	   @Mock
	    private SupplierInventoryRepository supplierInventoryRepository;

	    @InjectMocks
	    private SupplierInventoryService supplierInventoryService;

	    @Test
	    public void testGetAllSupplierInventories() {
	        // Mocking repository behavior
	        SupplierInventoryEntity inventory1 = new SupplierInventoryEntity("1", "Item1", "Supplier1", 10, 0, null);
	        SupplierInventoryEntity inventory2 = new SupplierInventoryEntity("2", "Item2", "Supplier2", 20, 0, null);
	        Mockito.when(supplierInventoryRepository.findAll()).thenReturn(Arrays.asList(inventory1, inventory2));

	        // Calling the service method
	        List<SupplierInventoryEntity> result = supplierInventoryService.getAllSupplierInventories();

	        // Assertions
	        assertEquals(2, result.size());
	        assertEquals("Item1", result.get(0).getItemName());
	        assertEquals("Item2", result.get(1).getItemName());
	    }

	    @Test
	    public void testGetSupplierInventoryById() {
	        // Mocking repository behavior
	        SupplierInventoryEntity inventory = new SupplierInventoryEntity("1", "Item1", "Supplier1", 10, 0, null);
	        Mockito.when(supplierInventoryRepository.findById("1")).thenReturn(Optional.of(inventory));

	        // Calling the service method
	        SupplierInventoryEntity result = supplierInventoryService.getSupplierInventoryById("1");

	        // Assertions
	        assertEquals("Item1", result.getItemName());
	        assertEquals("Supplier1", result.getSupplierUsername());
	        assertEquals(10, result.getQuantity());
	    }

	    @Test
	    public void testAddSupplierInventory() {
	        // Mocking repository behavior
	        SupplierInventoryEntity newInventory = new SupplierInventoryEntity(null, "NewItem", "NewSupplier", 15, 0, null);
	        Mockito.when(supplierInventoryRepository.save(any(SupplierInventoryEntity.class))).thenReturn(newInventory);

	        // Calling the service method
	        SupplierInventoryEntity result = supplierInventoryService.addSupplierInventory(newInventory);

	        // Assertions
	        assertEquals("NewItem", result.getItemName());
	        assertEquals("NewSupplier", result.getSupplierUsername());
	        assertEquals(15, result.getQuantity());
	    }
	    
	    @Test
	    public void testUpdateSupplierInventory() {
	        // Mocking repository behavior
	        SupplierInventoryEntity existingInventory = new SupplierInventoryEntity("1", "ExistingItem", "ExistingSupplier", 5, 0, null);
	        SupplierInventoryEntity updatedInventory = new SupplierInventoryEntity("1", "UpdatedItem", "UpdatedSupplier", 10, 0, null);

	        Mockito.when(supplierInventoryRepository.findById("1")).thenReturn(Optional.of(existingInventory));
	        Mockito.when(supplierInventoryRepository.save(any(SupplierInventoryEntity.class))).thenReturn(updatedInventory);

	        // Calling the service method
	        SupplierInventoryEntity result = supplierInventoryService.updateSupplierInventory("1", updatedInventory);

	        // Assertions
	        assertEquals("UpdatedItem", result.getItemName());
	        assertEquals("UpdatedSupplier", result.getSupplierUsername());
	        assertEquals(10, result.getQuantity());
	    }

	    @Test
	    public void testUpdateNonExistentSupplierInventory() {
	        // Mocking repository behavior
	        SupplierInventoryEntity updatedInventory = new SupplierInventoryEntity("1", "UpdatedItem", "UpdatedSupplier", 10, 0, null);

	        Mockito.when(supplierInventoryRepository.findById("1")).thenReturn(Optional.empty());

	        // Calling the service method
	        SupplierInventoryEntity result = supplierInventoryService.updateSupplierInventory("1", updatedInventory);

	        // Assertions
	        assertNull(result);
	    }

	    @Test
	    public void testDeleteSupplierInventory() {
	        // Mocking repository behavior
	        Mockito.doNothing().when(supplierInventoryRepository).deleteById("1");

	        // Calling the service method
	        supplierInventoryService.deleteSupplierInventory("1");

	        // No assertions, just ensuring that the delete method is called without exceptions
	    }

}
