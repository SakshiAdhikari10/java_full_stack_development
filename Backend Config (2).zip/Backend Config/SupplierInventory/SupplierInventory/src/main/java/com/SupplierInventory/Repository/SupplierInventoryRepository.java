package com.SupplierInventory.Repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.SupplierInventory.Entity.SupplierInventoryEntity;


public interface SupplierInventoryRepository extends MongoRepository<SupplierInventoryEntity, String>{

}
