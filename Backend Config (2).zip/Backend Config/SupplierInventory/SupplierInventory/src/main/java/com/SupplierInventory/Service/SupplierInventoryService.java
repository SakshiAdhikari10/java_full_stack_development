package com.SupplierInventory.Service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.SupplierInventory.Entity.SupplierInventoryEntity;
import com.SupplierInventory.Exception.DrugNotFoundException;
import com.SupplierInventory.Repository.SupplierInventoryRepository;

@Service
public class SupplierInventoryService {

    @Autowired
    private SupplierInventoryRepository supplierInventoryRepository;

    public List<SupplierInventoryEntity> getAllSupplierInventories() {
        return supplierInventoryRepository.findAll();
    }

    public SupplierInventoryEntity getSupplierInventoryById(String id) {
    	
        return supplierInventoryRepository.findById(id).orElseThrow(()->new DrugNotFoundException(id));
    }

    public SupplierInventoryEntity addSupplierInventory(SupplierInventoryEntity supplierInventory) {
        return supplierInventoryRepository.save(supplierInventory);
    }

    public SupplierInventoryEntity updateSupplierInventory(String id, SupplierInventoryEntity updatedInventory) {
        SupplierInventoryEntity existingInventory = supplierInventoryRepository.findById(id).orElse(null);
        if (existingInventory != null) {
            // Update inventory fields as needed
            existingInventory.setItemName(updatedInventory.getItemName());
            existingInventory.setSupplierUsername(updatedInventory.getSupplierUsername());
            existingInventory.setQuantity(updatedInventory.getQuantity());

            return supplierInventoryRepository.save(existingInventory);
        } else {
            return null;
        }
    }
 
    public void deleteSupplierInventory(String id) {
        supplierInventoryRepository.deleteById(id);
    }

}