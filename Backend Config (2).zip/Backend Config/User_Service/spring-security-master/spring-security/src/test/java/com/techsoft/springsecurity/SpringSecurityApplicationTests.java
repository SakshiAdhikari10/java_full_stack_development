
package com.techsoft.springsecurity;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Collections;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;

import com.techsoft.springsecurity.entity.UserInfo;
import com.techsoft.springsecurity.repository.UserInfoRepository;
import com.techsoft.springsecurity.service.UserInfoService;

@SpringBootTest
class SpringSecurityApplicationTests {

	@Test
	void contextLoads() {
	}


    @Mock
    private UserInfoRepository userInfoRepository;

    @Mock
    private PasswordEncoder passwordEncoder;

    @InjectMocks
    private UserInfoService userInfoService;
//
//    private Integer id;
//    private String name;
//    private String email;
//    private String roles;
//    private String password;
    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testLoadUserByUsername_UserFound() {
        String username = "testUser";
        UserInfo userInfo = new UserInfo(1, "sakshi", "sakshi@gmail.com", "admin", "sakshi@2001");
        when(userInfoRepository.findByName(username)).thenReturn(Optional.of(userInfo));

        assertEquals(username, userInfoService.loadUserByUsername(username).getUsername());

        verify(userInfoRepository, times(1)).findByName(username);
    }

    @Test
    void testLoadUserByUsername_UserNotFound() {
        String username = "nonExistentUser";
        when(userInfoRepository.findByName(username)).thenReturn(Optional.empty());

        assertThrows(UsernameNotFoundException.class, () -> userInfoService.loadUserByUsername(username));

        verify(userInfoRepository, times(1)).findByName(username);
    }

    @Test
    void testAddUser() {
        UserInfo userInfo = new UserInfo(1, "sakshi", "sakshi@gmail.com", "admin", "sakshi@2001");
        when(passwordEncoder.encode(userInfo.getPassword())).thenReturn("encodedPassword");
        when(userInfoRepository.save(userInfo)).thenReturn(userInfo);

        String result = userInfoService.addUser(userInfo);

        assertEquals("User added successfully", result);
        assertEquals("encodedPassword", userInfo.getPassword());

        verify(passwordEncoder, times(1)).encode(userInfo.getPassword());
        verify(userInfoRepository, times(1)).save(userInfo);
    }

    @Test
    void testGetAllUser() {
        when(userInfoRepository.findAll()).thenReturn(Collections.singletonList(new UserInfo()));

        assertEquals(1, userInfoService.getAllUser().size());

        verify(userInfoRepository, times(1)).findAll();
    }

    @Test
    void testGetUser() {
        Integer userId = 1;
        UserInfo userInfo = new UserInfo(userId, "testUser", "password", null, null);
        when(userInfoRepository.findById(userId)).thenReturn(Optional.of(userInfo));

        assertEquals(userId, userInfoService.getUser(userId).getId());

        verify(userInfoRepository, times(1)).findById(userId);
    }
}

