package com.Orders.Service;

import com.Orders.Entity.*;
import com.Orders.FeignClient.SupplierInventoryFeignClient;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Orders.Repository.OrderRepository;
//import com.mongodb.internal.operation.OperationHelper.ResourceSupplierInternalException;

@Service
public class OrderService {

	@Autowired
	private OrderRepository orderRepository;

	@Autowired
	private SupplierInventoryFeignClient supplierInventoryFeignClient;

	List<SupplierInventoryEntity> newOrderList = new ArrayList<>();

	public List<OrderEntity> getAllOrders() {

		List<OrderEntity> orderEntity = orderRepository.findAll();
		for (OrderEntity o : orderEntity) {
			List<SupplierInventoryEntity> orderList = new ArrayList<>();
			for (String e : o.getOrderIdList().keySet()) {

				newOrderList.add(supplierInventoryFeignClient.getSupplierInventoryById(e));
				orderList.add(supplierInventoryFeignClient.getSupplierInventoryById(e));
			}
			o.setOrderList(orderList);
		}

		return orderEntity;

	}


	public void addOrder(OrderEntity orderEntity) {
		
		long randomUserId =(long) (Math.random() * 2 * Long.MAX_VALUE - Long.MIN_VALUE);
		orderEntity.setId(randomUserId);
		orderRepository.save(orderEntity);

	}

	public String verifiedOrder(long orderId, boolean verifiedOrder) {

	 OrderEntity orderEntity = orderRepository.findById(orderId);
	  
		if (verifiedOrder == true) {
//			for (OrderEntity o : orderEntity) {
//				List<SupplierInventoryEntity> orderList = new ArrayList<>();
//				for (String e : o.getOrderIdList().keySet()) {
//                
//					SupplierInventoryEntity s = supplierInventoryFeignClient.getSupplierInventoryById(e);
//
//				}
//
//			}
			
			//for(OrderEntity o : orderEntity) {
				for(String id:orderEntity.getOrderIdList().keySet()) {
					SupplierInventoryEntity entity=	supplierInventoryFeignClient.getSupplierInventoryById(id);
					int available=entity.getQuantity()- orderEntity.getOrderIdList().get(id);
					entity.setQuantity(available);
					supplierInventoryFeignClient.updateSupplierInventory(id, entity);
				}
		//	}
			
//			
//
//			OrderEntity o = orderRepository.findById(orderId);
//			for (SupplierInventoryEntity s : newOrderList) {
//				if (o.getOrderIdList().containsKey(s.getId())) {
//					avalaible = s.getQuantity() - o.getOrderIdList().get(s.getId());
//					s.setQuantity(avalaible);
//					supplierInventoryFeignClient.updateSupplierInventory(s.getId(), s);
//				}
//
//			}
			return "Order verified successfully";

//				avalaible = s.getQuantity();
//
//				s.setQuantity(avalaible);
//
//				supplierInventoryFeignClient.updateSupplierInventory(s.getId(), s);
//
//			

		}
		return "Not a valid Order";

	}

	public String deleteOrder(long userId) {
		OrderEntity o = orderRepository.findById(userId);
		if (o != null)
		{
			orderRepository.deleteById(userId);
			return "delted successfully";
		}
		else
			return "failure";

	}

}
