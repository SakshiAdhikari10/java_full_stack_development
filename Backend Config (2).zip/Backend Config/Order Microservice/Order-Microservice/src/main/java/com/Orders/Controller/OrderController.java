package com.Orders.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.Orders.Entity.*;
import com.Orders.Repository.OrderRepository;
import com.Orders.Service.*;
import java.util.List;

@RestController
@RequestMapping("/api/orders")
public class OrderController {

	@Autowired
	private OrderService orderService;

	@GetMapping
	public ResponseEntity<List<OrderEntity>> getAllOrders() {
		List<OrderEntity> orders = orderService.getAllOrders();
		return new ResponseEntity<>(orders, HttpStatus.OK);
	}

	@PostMapping("/addToOrder")
	public void addOrder(@RequestBody OrderEntity order) {

		this.orderService.addOrder(order);
	}
	
//	@GetMapping("/{userId}")
//	public List<SupplierInventoryEntity> getOrderByUserId(@PathVariable long userId)
//	{
//		return this.orderService.getOrderByUserId(userId);
//	}

//	    @DeleteMapping("/deleteOrder/{orderId}")
//	    public String deleteOrder

	@GetMapping("/{orderId}/{verifiedOrder}")
	public String verifyOrder(@PathVariable long orderId, @PathVariable boolean verifiedOrder) {
		return this.orderService.verifiedOrder(orderId, verifiedOrder);
	}
	
	@DeleteMapping("/{userId}")
	public String deleteOrder(@PathVariable long userId)
	{
		return this.orderService.deleteOrder(userId);
		
	}

}
