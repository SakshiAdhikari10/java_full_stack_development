package com.Orders.Entity;

import org.springframework.data.annotation.Id;
import org.springframework.stereotype.Component;


@Component
public class SupplierInventoryEntity {

   
    private String id;

    private String itemName;
    private String supplierUsername;
    private int quantity;
    private double price;
    private String expiryDate;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public String getSupplierUsername() {
		return supplierUsername;
	}
	public void setSupplierUsername(String supplierUsername) {
		this.supplierUsername = supplierUsername;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public double getPrice() {
		return price;
	}
	
	public void setPrice(double price) {
		this.price = price;
	}
	public String getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}
	public SupplierInventoryEntity(String id, String itemName, String supplierUsername, int quantity, double price,
			String expiryDate) {
		super();
		this.id = id;
		this.itemName = itemName;
		this.supplierUsername = supplierUsername;
		this.quantity = quantity;
		this.price = price;
		this.expiryDate = expiryDate;
	}
	public SupplierInventoryEntity() {
		super();
	}

}
