package com.Orders.Repository;



import org.springframework.data.mongodb.repository.MongoRepository;

import com.Orders.Entity.*;

public interface OrderRepository extends MongoRepository<OrderEntity,Long> {
	OrderEntity findById(long orderId);
}
