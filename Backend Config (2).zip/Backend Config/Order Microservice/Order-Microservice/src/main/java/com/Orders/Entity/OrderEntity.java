package com.Orders.Entity;

import java.util.List;
import java.util.Map;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;


@Document(collection="order_db")
public class OrderEntity {

		@Id
		private Long id;
		private Double price;
		private int userId;
		private Map<String,Integer>orderIdList;
		private transient List<SupplierInventoryEntity>orderList;
		private boolean pickedupOrder;
		private boolean verifiedOrder;
		
		public Long getId() {
			return id;
		}
		public void setId(Long id) {
			this.id = id;
		}
		public Double getPrice() {
			return price;
		}
		public void setPrice(Double price) {
			this.price = price;
		}
		public int getUserId() {
			return userId;
		}
		public void setUserId(int userId) {
			this.userId = userId;
		}
		public Map<String,Integer> getOrderIdList() {
			return orderIdList;
		}
		public void setOrderIdList(Map<String,Integer> orderIdList) {
			this.orderIdList = orderIdList;
		}
		public List<SupplierInventoryEntity> getOrderList() {
			return orderList;
		}
		public void setOrderList(List<SupplierInventoryEntity> orderList) {
			this.orderList = orderList;
		}
		public boolean isPickedupOrder() {
			return pickedupOrder;
		}
		public void setPickedupOrder(boolean pickedupOrder) {
			this.pickedupOrder = pickedupOrder;
		}
		public boolean isVerifiedOrder() {
			return verifiedOrder;
		}
		public void setVerifiedOrder(boolean verifiedOrder) {
			this.verifiedOrder = verifiedOrder;
		}
		
		public OrderEntity(Long id, Double price, int userId, Map<String,Integer> orderIdList,
				List<SupplierInventoryEntity> orderList, boolean pickedupOrder, boolean verifiedOrder) {
			super();
			this.id = id;
			this.price = price;
			this.userId = userId;
			this.orderIdList = orderIdList;
			this.orderList = orderList;
			this.pickedupOrder = pickedupOrder;
			this.verifiedOrder = verifiedOrder;
		}
		public OrderEntity() {
			super();
			
		}
		
		
		
		
		
		
		

}
