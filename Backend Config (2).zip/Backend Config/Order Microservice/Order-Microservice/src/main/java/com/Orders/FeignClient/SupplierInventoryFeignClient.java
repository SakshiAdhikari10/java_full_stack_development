package com.Orders.FeignClient;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.Orders.Entity.SupplierInventoryEntity;

import java.util.List;

@FeignClient(url = "http://localhost:8080", value = "SUPPLIER-INVENTORY")
public interface SupplierInventoryFeignClient {

	@GetMapping("/api/supplier-inventory/{id}")
	public SupplierInventoryEntity getSupplierInventoryById(@PathVariable String id);

	@PutMapping("api/supplier-inventory/{id}")
    public SupplierInventoryEntity updateSupplierInventory(@PathVariable String id, @RequestBody SupplierInventoryEntity updatedInventory);
}
