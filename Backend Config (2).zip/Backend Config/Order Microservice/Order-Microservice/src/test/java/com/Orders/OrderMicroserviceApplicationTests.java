package com.Orders;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

import org.springframework.boot.test.context.SpringBootTest;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.mockito.InjectMocks;
import org.mockito.Mock;

import com.Orders.Entity.OrderEntity;
import com.Orders.Entity.SupplierInventoryEntity;
import com.Orders.FeignClient.SupplierInventoryFeignClient;
import com.Orders.Repository.OrderRepository;
import com.Orders.Service.OrderService;

@SpringBootTest
class OrderMicroserviceApplicationTests {

	@Test
	void contextLoads() {
	}

    @Mock
    private OrderRepository orderRepository;

    @Mock
    private SupplierInventoryFeignClient supplierInventoryFeignClient;

    @InjectMocks
    private OrderService orderService;

    @Test
    public void testGetAllOrders() {
        // Mock data
        List<OrderEntity> mockOrders = new ArrayList<>();
        OrderEntity mockOrder = new OrderEntity();
        mockOrder.setOrderIdList(new HashMap<>());
        mockOrders.add(mockOrder);

        List<SupplierInventoryEntity> mockSupplierInventoryList = new ArrayList<>();
        SupplierInventoryEntity mockSupplierInventory = new SupplierInventoryEntity();
        mockSupplierInventory.setId("supplier1");
        mockSupplierInventoryList.add(mockSupplierInventory);

        // Mock behavior
        when(orderRepository.findAll()).thenReturn(mockOrders);
        when(supplierInventoryFeignClient.getSupplierInventoryById(any())).thenReturn(mockSupplierInventory);

        // Call the method to be tested
        List<OrderEntity> result = orderService.getAllOrders();

        // Assertions
        // Add your assertions based on the expected behavior of getAllOrders()

        // Verify that the methods were called as expected
        verify(orderRepository, times(1)).findAll();
        verify(supplierInventoryFeignClient, times(mockOrders.size())).getSupplierInventoryById(any());
    }

    @Test
    public void testAddOrder() {
        // Mock data
        OrderEntity mockOrder = new OrderEntity();

        // Mock behavior
        when(orderRepository.save(any())).thenReturn(mockOrder);

        // Call the method to be tested
        orderService.addOrder(mockOrder);

        // Verify that the method was called as expected
        verify(orderRepository, times(1)).save(mockOrder);
    }

    // Add similar tests for other methods (verifiedOrder, deleteOrder)
    @Test
    public void testDeleteOrder() {
        // Mock data
        long mockOrderId = 1L;
        OrderEntity mockOrder = new OrderEntity();
        mockOrder.setId(mockOrderId);

        // Mock behavior
        when(orderRepository.findById(mockOrderId)).thenReturn(mockOrder);
        doNothing().when(orderRepository).deleteById(mockOrderId);

        // Call the method to be tested
        String result = orderService.deleteOrder(mockOrderId);

        // Assertions
        // Add your assertions based on the expected behavior of deleteOrder()
        assertEquals("deleted successfully", result);

        // Verify that the methods were called as expected
        verify(orderRepository, times(1)).findById(mockOrderId);
        verify(orderRepository, times(1)).deleteById(mockOrderId);
    }


}
